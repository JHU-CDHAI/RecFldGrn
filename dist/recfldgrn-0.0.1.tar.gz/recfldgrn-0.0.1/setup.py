from setuptools import setup, find_packages

setup(
    name='recfldgrn',
    version='0.0.1',
    description='Your package description',
    author='Your Name',
    author_email='junjie.luo.jhu@gmail.com',
    packages=find_packages(),  # Automatically find all packages
)